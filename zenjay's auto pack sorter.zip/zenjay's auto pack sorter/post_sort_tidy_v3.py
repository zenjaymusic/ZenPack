#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# post_sort_tidy_v3.py — portable, single-pass tidy
# - FX\Unknown → Atmospheres (foley/field) or LOOPS\Melodic Loops (melodic/BPM, non-drum)
# - DRUMS\Cymbals → move melodic stems out to LOOPS\Melodic Loops (fix 'Ride' false-positives)
# - MIDI\Unknown → MIDI\Melodic MIDI
# - REFERENCE (Unknown + optional ROOT sweep) → Documentation/Scripts/Ableton Analysis
# Dry-run by default; use --commit to apply. Use --root to point at your Sorted folder.


import argparse, shutil, sys, time
from pathlib import Path

# ---------- Console: UTF-8 guard (Windows friendly) ----------
for _s in (getattr(sys, "stdout", None), getattr(sys, "stderr", None)):
    try:
        if _s and hasattr(_s, "reconfigure"):
            _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# ---------- Args ----------
def parse_args():
    ap = argparse.ArgumentParser(description="Post-sort tidy v3 (FX Unknown, Cymbals fix, MIDI Unknown, Reference sweep).")
    ap.add_argument("--root", default=r"Z:\Audio Master\!PACKS\01 - LIBRARIES\01 - CYMATICS\Sorted_Cymatics",
                    help="Path to the *Sorted* root (e.g., ...\\Sorted_Cymatics or ...\\REMNANT_SORTED).")
    ap.add_argument("--commit", action="store_true", help="Apply changes (default: dry-run).")
    ap.add_argument("--no-root-sweep", action="store_true", help="Skip sweeping ROOT for stray logs/scripts.")
    return ap.parse_args()

args = parse_args()
ROOT = Path(args.root)
ROOT.mkdir(parents=True, exist_ok=True)  # ensure exists

LOG = ROOT / "post_sort_tidy_v3_log.txt"
def log(msg: str):
    ts = time.strftime("[%Y-%m-%d %H:%M:%S]")
    line = f"{ts} {msg}"
    print(line)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")

# ---------- Canonical subpaths (relative to ROOT) ----------
FX_UNKNOWN = ROOT / r"05 - FX" / "Unknown"
FX_ATMOS   = ROOT / r"05 - FX" / "Atmospheres"
LOOPS_MELODIC = ROOT / r"02 - LOOPS" / "Melodic Loops"

CYMBALS = ROOT / r"01 - DRUMS" / "Cymbals"

MIDI_UNKNOWN = ROOT / r"04 - MIDI" / "Unknown"
MIDI_MELODIC = ROOT / r"04 - MIDI" / "Melodic MIDI"

REF_UNKNOWN = ROOT / r"09 - REFERENCE" / "Unknown"
REF_DOCS    = ROOT / r"09 - REFERENCE" / "Documentation"
REF_SCRIPTS = REF_DOCS / "Scripts"
REF_ASD     = REF_DOCS / "Ableton Analysis"

SWEEP_ROOT_FOR_REF = not args.no_root_sweep

# ---------- Heuristics ----------
AUDIO_EXT = {".wav",".aiff",".aif",".flac",".mp3",".ogg",".wma"}
MIDI_EXT  = {".mid",".midi"}
LOG_EXT   = {".txt",".log",".csv"}
PY_EXT    = {".py"}
ASD_EXT   = {".asd"}

FOLEY_KEYS   = {"walk","walking","footstep","forest","leaf","leaves","sand","park","life","foley","field","ocean","rain"}
MELODIC_KEYS = {"melodic","melody","chord","guitar","piano","keys","pluck","arp","bordeaux","champagne","loop",
                "pad","bell","brass","string","strings","choir","vox","vocal","lead","synth","organ","harp","flute"}
DRUM_HINTS   = {"kick","snare","clap","hat","hihat","hi-hat","perc","tom","808"}

CYMBALS_MELODIC_TOKENS = {"piano","pad","synth","bass","texture","vocal","vocals","keys","guitar","pluck","arp","string","strings"}
RIDE_FALSE_POS = "ride or die"

def ensure_dirs(*paths: Path):
    for p in paths: p.mkdir(parents=True, exist_ok=True)

def unique_dest(dst_dir: Path, name: str) -> Path:
    dst = dst_dir / name
    if not dst.exists(): return dst
    base, ext = dst.stem, dst.suffix
    i = 2
    while (dst_dir / f"{base} ({i}){ext}").exists(): i += 1
    return dst_dir / f"{base} ({i}){ext}"

def move(src: Path, dst_dir: Path, commit: bool):
    dst_dir.mkdir(parents=True, exist_ok=True)
    final = unique_dest(dst_dir, src.name)
    if not commit:
        log(f"DRY-RUN: {src}  ->  {final}")
        return True
    try:
        shutil.move(str(src), str(final))
        log(f"MOVED: {src}  ->  {final}")
        return True
    except Exception as e:
        log(f"ERROR moving {src}: {e}")
        return False

def should_go_foley(name: str, ext: str) -> bool:
    return ext in AUDIO_EXT and any(k in name for k in FOLEY_KEYS)

def should_go_melodic_loop(name: str, ext: str) -> bool:
    if ext not in AUDIO_EXT: return False
    if any(d in name for d in DRUM_HINTS): return False
    return ("bpm" in name) or ("loop" in name) or any(k in name for k in MELODIC_KEYS)

def cymbals_is_melodic_stem(name: str) -> bool:
    if RIDE_FALSE_POS in name: return True
    return any(tok in name for tok in CYMBALS_MELODIC_TOKENS)

# ---------- Sweeps ----------
def sweep_fx_unknown(commit: bool):
    moved_foley = moved_melodic = skipped = 0
    if not FX_UNKNOWN.exists(): return (0,0,0)
    for p in sorted(FX_UNKNOWN.iterdir()):
        if not p.is_file(): continue
        nm, ext = p.name.lower(), p.suffix.lower()
        if should_go_foley(nm, ext):
            if move(p, FX_ATMOS, commit): moved_foley += 1
        elif should_go_melodic_loop(nm, ext):
            if move(p, LOOPS_MELODIC, commit): moved_melodic += 1
        else:
            skipped += 1
    return (moved_foley, moved_melodic, skipped)

def sweep_cymbals(commit: bool):
    moved = skipped = 0
    if not CYMBALS.exists(): return (0,0)
    for p in sorted(CYMBALS.iterdir()):
        if not p.is_file(): continue
        if cymbals_is_melodic_stem(p.name.lower()):
            if move(p, LOOPS_MELODIC, commit): moved += 1
        else:
            skipped += 1
    return (moved, skipped)

def sweep_midi_unknown(commit: bool):
    moved = skipped = 0
    if not MIDI_UNKNOWN.exists(): return (0,0)
    for p in sorted(MIDI_UNKNOWN.rglob("*")):
        if p.is_file() and p.suffix.lower() in MIDI_EXT:
            if move(p, MIDI_MELODIC, commit): moved += 1
        else:
            if p.is_file(): skipped += 1
    return (moved, skipped)

def sweep_reference(commit: bool, include_root: bool):
    moved_scripts = moved_logs = moved_asd = 0
    ensure_dirs(REF_DOCS, REF_SCRIPTS, REF_ASD)
    targets = []
    if REF_UNKNOWN.exists(): targets.append(REF_UNKNOWN)
    if include_root and ROOT.exists(): targets.append(ROOT)
    for base in targets:
        for p in sorted(base.rglob("*")):
            if not p.is_file(): continue
            ext = p.suffix.lower()
            if ext in PY_EXT:
                if move(p, REF_SCRIPTS, commit): moved_scripts += 1
            elif ext in LOG_EXT:
                if move(p, REF_DOCS, commit): moved_logs += 1
            elif ext in ASD_EXT:
                if move(p, REF_ASD, commit): moved_asd += 1
    return (moved_scripts, moved_logs, moved_asd)

def prune_if_empty(path: Path, commit: bool):
    try:
        if path.exists() and not any(path.rglob("*")):
            if commit:
                path.rmdir(); log(f"Removed empty folder: {path}")
            else:
                log(f"DRY-RUN: would remove empty folder: {path}")
    except Exception:
        pass

# ---------- Main ----------
def main():
    # Log header
    with open(LOG, "a", encoding="utf-8") as f:
        f.write("\n" + "="*80 + "\n")
        f.write(time.strftime("RUN START: %Y-%m-%d %H:%M:%S") + "\n")
        f.write(f"ROOT: {ROOT}\n")
        f.write(f"MODE: {'COMMIT' if args.commit else 'DRY-RUN'}\n")
        f.write("="*80 + "\n")

    log(f"Root: {ROOT} | Mode: {'COMMIT' if args.commit else 'DRY-RUN'}")

    ensure_dirs(FX_ATMOS, LOOPS_MELODIC, MIDI_MELODIC, REF_DOCS, REF_SCRIPTS, REF_ASD)

    f_f, f_m, f_s = sweep_fx_unknown(commit=args.commit)
    log(f"FX\\Unknown → Atmospheres/Melodic: foley={f_f}, melodic={f_m}, skipped={f_s}")

    c_m, c_s = sweep_cymbals(commit=args.commit)
    log(f"Cymbals → Melodic Loops (false-positives fixed): moved={c_m}, skipped={c_s}")

    m_m, m_s = sweep_midi_unknown(commit=args.commit)
    log(f"MIDI\\Unknown → Melodic MIDI: moved={m_m}, skipped-non-midi={m_s}")

    r_s, r_l, r_a = sweep_reference(commit=args.commit, include_root=SWEEP_ROOT_FOR_REF)
    log(f"REFERENCE sweep: scripts={r_s}, logs={r_l}, ableton_asd={r_a}")

    for p in [FX_UNKNOWN, MIDI_UNKNOWN, REF_UNKNOWN]:
        prune_if_empty(p, commit=args.commit)

    log("Run end.")

if __name__ == "__main__":
    main()
