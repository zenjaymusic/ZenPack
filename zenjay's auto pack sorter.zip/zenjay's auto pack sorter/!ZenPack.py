#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, sys, threading, subprocess, queue, time, shlex
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# -------- CONFIG DEFAULTS (edit if you need) --------
DEFAULT_ROOT = r"Z:\Audio Master\!PACKS\01 - LIBRARIES\02 - REMNANT"
DEFAULT_SORTED = r"Z:\Audio Master\!PACKS\01 - LIBRARIES\02 - REMNANT\REMNANT_SORTED"

# expected script filenames (place this GUI file in the SAME folder as these)
SCRIPT_NAMES = {
    "unzip_recursive": "unzip_unpack_recursive.py",
    "cleanup": "cleanup_irrelevant.py",
    "sort_copy": "structure_sort.py",
    "sort_move": "structure_sort_move.py",
    "tidy_v3": "post_sort_tidy_v3.py",
    "tree_scan": "tree_scan.py",               # optional (pretty tree + CSVs)
    "tree_log": "tree_scanner.py",             # optional (simple txt log)
}

PYTHON_EXE = sys.executable  # use current Python

# ----------------------------------------------------

def quote(arg: str) -> str:
    # robust quoting for Windows paths with spaces
    if not arg:
        return '""'
    if " " in arg or "(" in arg or ")" in arg or "!" in arg:
        return f'"{arg}"'
    return arg

class Runner:
    def __init__(self, console_widget: tk.Text):
        self.console = console_widget
        self.proc = None
        self.q = queue.Queue()
        self.stop_flag = False

    def log(self, msg: str):
        self.console.after(0, lambda: self._append(msg))

    def _append(self, msg: str):
        self.console.configure(state="normal")
        self.console.insert("end", msg + "\n")
        self.console.see("end")
        self.console.configure(state="disabled")

    def run_cmd(self, cmd_list, cwd=None):
        """Run a command, streaming stdout/stderr to console, in a worker thread."""
        def worker():
            try:
                self.log(f">>> {' '.join(map(quote, cmd_list))}")
                self.proc = subprocess.Popen(
                    cmd_list,
                    cwd=cwd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    bufsize=1
                )
                for line in self.proc.stdout:
                    if line is None:
                        break
                    self.log(line.rstrip("\n"))
                rc = self.proc.wait()
                self.log(f"[exit {rc}]")
            except Exception as e:
                self.log(f"[error] {e}")
            finally:
                self.proc = None

        threading.Thread(target=worker, daemon=True).start()

    def terminate(self):
        try:
            if self.proc and self.proc.poll() is None:
                self.proc.terminate()
                self.log("[terminated]")
        except Exception as e:
            self.log(f"[terminate error] {e}")

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ZenPack • GUI")
        self.geometry("980x720")
        self.minsize(900, 640)

        self.script_dir = Path(__file__).resolve().parent

        # state vars
        self.root_var = tk.StringVar(value=DEFAULT_ROOT)
        self.sorted_var = tk.StringVar(value=DEFAULT_SORTED)

        self.chk_dry_cleanup = tk.BooleanVar(value=False)
        self.chk_copy_dry = tk.BooleanVar(value=False)
        self.dup_policy = tk.StringVar(value="skip")  # for move
        self.chk_tidy_commit = tk.BooleanVar(value=False)
        self.chk_tidy_no_root_sweep = tk.BooleanVar(value=False)

        # build UI
        self._build_header()
        self._build_actions()
        self._build_console()

        self.runner = Runner(self.txt_console)

    # ---------- UI ----------
    def _build_header(self):
        frm = ttk.LabelFrame(self, text="Paths")
        frm.pack(fill="x", padx=10, pady=8)

        # root
        ttk.Label(frm, text="Root:").grid(row=0, column=0, sticky="w", padx=8, pady=6)
        ent_root = ttk.Entry(frm, textvariable=self.root_var, width=100)
        ent_root.grid(row=0, column=1, sticky="we", padx=8, pady=6)
        ttk.Button(frm, text="Browse…", command=self.browse_root).grid(row=0, column=2, padx=8, pady=6)

        # sorted
        ttk.Label(frm, text="Sorted folder:").grid(row=1, column=0, sticky="w", padx=8, pady=6)
        ent_sorted = ttk.Entry(frm, textvariable=self.sorted_var, width=100)
        ent_sorted.grid(row=1, column=1, sticky="we", padx=8, pady=6)
        ttk.Button(frm, text="Browse…", command=self.browse_sorted).grid(row=1, column=2, padx=8, pady=6)

        frm.grid_columnconfigure(1, weight=1)

    def _build_actions(self):
        frm = ttk.LabelFrame(self, text="Actions")
        frm.pack(fill="x", padx=10, pady=8)

        # Row 1: unzip + cleanup
        r1 = ttk.Frame(frm); r1.pack(fill="x", pady=(6,0))
        ttk.Button(r1, text="1) Recursive Unpack (.zip/.rar)", command=self.do_unzip).pack(side="left", padx=6)
        ttk.Button(r1, text="2) Cleanup Junk", command=self.do_cleanup).pack(side="left", padx=6)
        ttk.Checkbutton(r1, text="Cleanup dry-run", variable=self.chk_dry_cleanup).pack(side="left", padx=12)

        # Row 2: sorters
        r2 = ttk.Frame(frm); r2.pack(fill="x", pady=(6,0))
        ttk.Button(r2, text="3) Copy → Sorted (locked layout)", command=self.do_sort_copy).pack(side="left", padx=6)
        ttk.Checkbutton(r2, text="Copy dry-run", variable=self.chk_copy_dry).pack(side="left", padx=12)

        r3 = ttk.Frame(frm); r3.pack(fill="x", pady=(6,0))
        ttk.Button(r3, text="4) Move → Sorted (commit)", command=self.do_sort_move).pack(side="left", padx=6)
        ttk.Label(r3, text="On duplicate:").pack(side="left", padx=(12,4))
        ttk.OptionMenu(r3, self.dup_policy, "skip", "skip", "rename", "overwrite").pack(side="left")

        # Row 3: tidy
        r4 = ttk.Frame(frm); r4.pack(fill="x", pady=(6,0))
        ttk.Button(r4, text="5) Post-tidy v3 (FX/Cymbals/MIDI/Ref)", command=self.do_tidy_v3).pack(side="left", padx=6)
        ttk.Checkbutton(r4, text="Commit", variable=self.chk_tidy_commit).pack(side="left", padx=12)
        ttk.Checkbutton(r4, text="Skip ROOT sweep", variable=self.chk_tidy_no_root_sweep).pack(side="left", padx=12)

        # Row 4: tree scans
        r5 = ttk.Frame(frm); r5.pack(fill="x", pady=(6,0))
        ttk.Button(r5, text="6) Tree Scan (pretty + CSVs)", command=self.do_tree_scan).pack(side="left", padx=6)
        ttk.Button(r5, text="7) Simple Tree Log", command=self.do_tree_log).pack(side="left", padx=6)

        # Row 5: pipeline
        r6 = ttk.Frame(frm); r6.pack(fill="x", pady=(10,6))
        ttk.Button(r6, text="RUN 1→5 Pipeline (Unpack→Cleanup→Copy→Move?→Tidy)",
                   command=self.do_pipeline).pack(side="left", padx=6)
        ttk.Button(r6, text="Stop Current", command=self.stop_current).pack(side="left", padx=6)

    def _build_console(self):
        frm = ttk.LabelFrame(self, text="Console")
        frm.pack(fill="both", expand=True, padx=10, pady=(0,10))
        self.txt_console = tk.Text(frm, wrap="word", height=24, state="disabled")
        yscroll = ttk.Scrollbar(frm, orient="vertical", command=self.txt_console.yview)
        self.txt_console.configure(yscrollcommand=yscroll.set)
        self.txt_console.pack(side="left", fill="both", expand=True)
        yscroll.pack(side="right", fill="y")

    # ---------- helpers ----------
    def browse_root(self):
        d = filedialog.askdirectory(initialdir=self.root_var.get() or DEFAULT_ROOT)
        if d:
            self.root_var.set(d)

    def browse_sorted(self):
        d = filedialog.askdirectory(initialdir=self.sorted_var.get() or DEFAULT_SORTED)
        if d:
            self.sorted_var.set(d)

    def script_path(self, key: str) -> Path:
        return self.script_dir / SCRIPT_NAMES[key]

    def check_script(self, key: str) -> bool:
        p = self.script_path(key)
        if not p.exists():
            messagebox.showerror("Missing script", f"Cannot find:\n{p}\n\nPlace this GUI next to your scripts.")
            return False
        return True

    def stop_current(self):
        self.runner.terminate()

    # ---------- actions ----------
    def do_unzip(self):
        if not self.check_script("unzip_recursive"): return
        root = self.root_var.get()
        cmd = [PYTHON_EXE, str(self.script_path("unzip_recursive")), "--source", root, "--dest", root]
        self.runner.run_cmd(cmd, cwd=str(self.script_dir))

    def do_cleanup(self):
        if not self.check_script("cleanup"): return
        root = self.root_var.get()
        cmd = [PYTHON_EXE, str(self.script_path("cleanup")), "--root", root]
        if self.chk_dry_cleanup.get():
            cmd.append("--dry-run")
        self.runner.run_cmd(cmd, cwd=str(self.script_dir))

    def do_sort_copy(self):
        if not self.check_script("sort_copy"): return
        root = self.root_var.get()
        out = self.sorted_var.get()
        cmd = [PYTHON_EXE, str(self.script_path("sort_copy")), "--root", root, "--out", out]
        if self.chk_copy_dry.get():
            cmd.append("--dry-run")
        self.runner.run_cmd(cmd, cwd=str(self.script_dir))

    def do_sort_move(self):
        if not self.check_script("sort_move"): return
        root = self.root_var.get()
        out = self.sorted_var.get()
        cmd = [PYTHON_EXE, str(self.script_path("sort_move")), "--root", root, "--out", out,
               "--on-duplicate", self.dup_policy.get()]
        self.runner.run_cmd(cmd, cwd=str(self.script_dir))

    def do_tidy_v3(self):
        if not self.check_script("tidy_v3"): return
        out = self.sorted_var.get()
        # Tidy v3 uses ROOT baked inside; many of our scripts do. We’ll call it as-is.
        cmd = [PYTHON_EXE, str(self.script_path("tidy_v3"))]
        if self.chk_tidy_commit.get():
            cmd.append("--commit")
        if self.chk_tidy_no_root_sweep.get():
            cmd.append("--no-root-sweep")
        self.runner.run_cmd(cmd, cwd=str(self.script_dir))

    def do_tree_scan(self):
        if not self.check_script("tree_scan"): return
        out = self.sorted_var.get()
        cmd = [PYTHON_EXE, str(self.script_path("tree_scan")), "--root", out, "--max-depth", "-1"]
        self.runner.run_cmd(cmd, cwd=str(self.script_dir))

    def do_tree_log(self):
        if not self.check_script("tree_log"): return
        out = self.sorted_var.get()
        cmd = [PYTHON_EXE, str(self.script_path("tree_log"))]  # uses baked path inside script
        self.runner.run_cmd(cmd, cwd=str(self.script_dir))

    def do_pipeline(self):
        """Run: Unpack → Cleanup → Copy-sort → (optional Move) → Tidy v3
           This is a simple sequential launcher; each step starts when the previous exits.
        """
        steps = []

        # 1) unzip
        if self.check_script("unzip_recursive"):
            steps.append([PYTHON_EXE, str(self.script_path("unzip_recursive")), "--source", self.root_var.get(), "--dest", self.root_var.get()])

        # 2) cleanup
        if self.check_script("cleanup"):
            cmd = [PYTHON_EXE, str(self.script_path("cleanup")), "--root", self.root_var.get()]
            if self.chk_dry_cleanup.get(): cmd.append("--dry-run")
            steps.append(cmd)

        # 3) copy-sort
        if self.check_script("sort_copy"):
            cmd = [PYTHON_EXE, str(self.script_path("sort_copy")), "--root", self.root_var.get(), "--out", self.sorted_var.get()]
            if self.chk_copy_dry.get(): cmd.append("--dry-run")
            steps.append(cmd)

        # 4) move-sort (optional; ask)
        if self.check_script("sort_move"):
            if messagebox.askyesno("Move mode", "Run Move → Sorted (commit)?\n\nFiles will be moved into Sorted_Cymatics."):
                steps.append([PYTHON_EXE, str(self.script_path("sort_move")), "--root", self.root_var.get(), "--out", self.sorted_var.get(),
                              "--on-duplicate", self.dup_policy.get()])

        # 5) tidy v3
        if self.check_script("tidy_v3"):
            cmd = [PYTHON_EXE, str(self.script_path("tidy_v3"))]
            # ask if commit
            if messagebox.askyesno("Tidy v3", "Commit tidy v3 changes now? (Otherwise dry-run)"):
                cmd.append("--commit")
            if self.chk_tidy_no_root_sweep.get(): cmd.append("--no-root-sweep")
            steps.append(cmd)

        def run_steps():
            for cmd in steps:
                self.runner.run_cmd(cmd, cwd=str(self.script_dir))
                # wait for previous process to finish
                while self.runner.proc is not None and self.runner.proc.poll() is None:
                    time.sleep(0.2)
            self.runner.log("Pipeline complete.")

        threading.Thread(target=run_steps, daemon=True).start()


if __name__ == "__main__":
    # nicer default ttk theme if available
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    app = App()
    app.mainloop()
