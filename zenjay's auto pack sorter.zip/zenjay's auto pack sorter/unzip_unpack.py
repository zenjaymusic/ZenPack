
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
unzip_unpack.py  (ZEN edition v2)
---------------------------------
Now accepts either a **folder OR a single archive file** as --source.

Key features:
- Defaults to Jay's paths (no args needed)
- Auto-detects 7-Zip (for .zip + .rar)
- Smart folder handling (no duplicate parent folder)
- Idempotent (skips already extracted unless --force)
- Robust UTF-8 logging + clear terminal output
- Graceful on errors; continues

USAGE
-----
Double-click (uses defaults), or run in PowerShell/CMD:
  python unzip_unpack.py
  python unzip_unpack.py --dry-run
  python unzip_unpack.py --source "Z:/.../CYMATICS.rar"   # single file allowed
  python unzip_unpack.py --source "D:/SourceFolder" --dest "D:/Dest" --force

Author: zen
"""

import argparse
import os
import sys
import subprocess
import time
import zipfile
from pathlib import Path
from typing import Optional, Tuple, List

# ======== DEFAULTS (edit if needed) ========
DEFAULT_SOURCE = r"Z:/Audio Master/!PACKS/01 - LIBRARIES/01 - CYMATICS"
DEFAULT_DEST   = r"Z:/Audio Master/!PACKS/01 - LIBRARIES/01 - CYMATICS"

SCRIPT_DIR = Path(__file__).resolve().parent
LOG_PATH = SCRIPT_DIR / "unzip_unpack_log.txt"


def log(msg: str, *, also_file: bool = True) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    if also_file:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")


def find_sevenzip(user_path: Optional[str] = None) -> Optional[Path]:
    """Return a Path to 7z.exe if available, else None."""
    try_candidates = []

    if user_path:
        try_candidates.append(Path(user_path).expanduser())

    # Common Windows install paths
    try_candidates += [
        Path(r"C:\Program Files\7-Zip\7z.exe"),
        Path(r"C:\Program Files (x86)\7-Zip\7z.exe"),
    ]

    # PATH lookup
    for dir_ in os.environ.get("PATH", "").split(os.pathsep):
        if not dir_:
            continue
        try_candidates.append(Path(dir_) / "7z.exe")

    for p in try_candidates:
        try:
            if p.exists():
                return p.resolve()
        except Exception:
            continue
    return None


def zip_has_single_top_dir(zf: zipfile.ZipFile) -> Tuple[bool, Optional[str]]:
    """Detect if a .zip has exactly one top-level directory; return (True, 'dirname') if so."""
    names = [n for n in zf.namelist() if n and not n.endswith('/')]
    top_levels = set()
    for n in names:
        top = n.split('/', 1)[0]
        if top:
            top_levels.add(top)
    # If there are no files but there is exactly one directory, still treat as single dir
    if not names:
        # Look at directories
        dir_entries = [n for n in zf.namelist() if n.endswith('/')]
        tl = set(d.split('/', 1)[0] for d in dir_entries if d)
        if len(tl) == 1:
            only = next(iter(tl))
            return True, only
        return False, None

    if len(top_levels) == 1:
        only = next(iter(top_levels))
        # Confirm it's actually a directory (has children)
        if any(m.startswith(only + "/") for m in zf.namelist() if m != only):
            return True, only
    return False, None


def sevenzip_list_toplevels(sevenzip: Path, archive: Path) -> Optional[set]:
    """Use 7z to list entries and compute top-level names. Returns set or None on failure."""
    try:
        result = subprocess.run([str(sevenzip), "l", "-ba", str(archive)],
                                capture_output=True, text=True, encoding="utf-8", errors="ignore")
        if result.returncode != 0:
            return None
        tops = set()
        for line in result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            path = parts[-1] if parts else ""
            if not path or path in (".", ".."):
                continue
            path = path.replace("\\", "/")
            top = path.split("/", 1)[0]
            if top:
                tops.add(top)
        return tops or None
    except Exception:
        return None


def extract_with_7z(sevenzip: Path, archive: Path, dest: Path) -> Tuple[bool, str]:
    try:
        dest.mkdir(parents=True, exist_ok=True)
        proc = subprocess.run([str(sevenzip), "x", "-y", f"-o{str(dest)}", str(archive), "-bso0", "-bsp0"],
                              capture_output=True, text=True, encoding="utf-8", errors="ignore")
        if proc.returncode == 0:
            return True, "OK (7z)"
        return False, f"7z failed (code {proc.returncode})"
    except Exception as e:
        return False, f"7z error: {e}"


def extract_zip_stdlib(archive: Path, dest: Path) -> Tuple[bool, str]:
    try:
        dest.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(archive, 'r') as zf:
            zf.extractall(dest)
        return True, "OK (zipfile)"
    except Exception as e:
        return False, f"zipfile error: {e}"


def already_extracted(dest_root: Path, archive: Path) -> bool:
    """Treat as extracted if dest/<archive-name> exists OR a single top dir exists at dest (cheap check)."""
    base = archive.stem
    if (dest_root / base).exists():
        return True
    return False


def process_archive(archive: Path, dest_root: Path, sevenzip: Optional[Path], dry_run: bool, force: bool) -> Tuple[bool, float, str]:
    start = time.time()
    status = ""
    try:
        if not archive.exists():
            return False, 0.0, "Missing archive"

        if (not force) and already_extracted(dest_root, archive):
            return True, 0.0, "Skipped (already extracted)"

        ext = archive.suffix.lower()
        single_dir = False
        inner = None

        if sevenzip:
            tops = sevenzip_list_toplevels(sevenzip, archive)
            if tops and len(tops) == 1:
                inner = next(iter(tops))
                single_dir = True
        elif ext == ".zip":
            try:
                with zipfile.ZipFile(archive, 'r') as zf:
                    single_dir, inner = zip_has_single_top_dir(zf)
            except Exception:
                pass

        extract_to = dest_root if single_dir else (dest_root / archive.stem)

        if dry_run:
            status = f"DRY-RUN: would extract to '{extract_to}' (single_dir={single_dir}, inner='{inner}')"
            return True, time.time() - start, status

        if sevenzip:
            ok, msg = extract_with_7z(sevenzip, archive, extract_to)
        elif ext == ".zip":
            ok, msg = extract_zip_stdlib(archive, extract_to)
        else:
            ok, msg = False, "No 7-Zip available for .rar; install 7-Zip"

        status = msg
        return ok, time.time() - start, status
    except Exception as e:
        return False, time.time() - start, f"Unhandled error: {e}"


def discover_archives(source: Path) -> List[Path]:
    """Return a list of archives. Accepts either a single file or a folder (recursive)."""
    if source.is_file():
        # Only accept if it's .zip or .rar
        if source.suffix.lower() in (".zip", ".rar"):
            return [source]
        return []
    if not source.exists():
        return []
    archives: List[Path] = []
    for p in source.rglob("*"):
        if p.is_file() and p.suffix.lower() in (".zip", ".rar"):
            archives.append(p)
    archives.sort()
    return archives


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract .zip/.rar archives with smart folder handling and robust logging.")
    parser.add_argument("--source", default=DEFAULT_SOURCE,
                        help=f"Folder OR single archive (.zip/.rar). Default: {DEFAULT_SOURCE}")
    parser.add_argument("--dest", default=DEFAULT_DEST,
                        help=f"Destination root for extracted content. Default: {DEFAULT_DEST}")
    parser.add_argument("--dry-run", action="store_true", help="List actions without extracting.")
    parser.add_argument("--force", action="store_true", help="Re-extract even if destination appears to exist.")
    args = parser.parse_args()

    source = Path(args.source).expanduser()
    dest = Path(args.dest).expanduser()

    # Log header
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write("\n" + "="*80 + "\n")
        f.write(time.strftime("RUN START: %Y-%m-%d %H:%M:%S") + "\n")
        f.write(f"SOURCE: {source}\nDEST: {dest}\nDRY_RUN: {args.dry_run}\nFORCE: {args.force}\n")
        f.write("="*80 + "\n")

    log("Starting unzip_unpack.py")
    log(f"Source: {source}")
    log(f"Destination: {dest}")

    if not source.exists():
        log("ERROR: Source path does not exist.")
        return 2

    dest.mkdir(parents=True, exist_ok=True)

    sevenzip = find_sevenzip()
    if sevenzip:
        log(f"7-Zip found at: {sevenzip}")
    else:
        log("7-Zip NOT found. .rar archives will FAIL; .zip will still be handled.")
        log("Tip: install via 'winget install -e --id 7zip.7zip' or 'choco install 7zip' then re-run.")

    archives = discover_archives(source)
    if not archives:
        log("No .zip or .rar archives found at the provided source. Nothing to do.")
        return 0

    log(f"Discovered {len(archives)} archive(s). Beginning extraction...")

    total_ok = 0
    total_fail = 0
    for i, arc in enumerate(archives, 1):
        log(f"[{i}/{len(archives)}] Processing: {arc}")
        ok, secs, msg = process_archive(arc, dest, sevenzip, args.dry_run, args.force)
        if ok:
            total_ok += 1
            log(f"SUCCESS in {secs:.2f}s: {msg}")
        else:
            total_fail += 1
            log(f"FAIL in {secs:.2f}s: {msg}")

    log("-" * 60)
    log(f"Completed. Success: {total_ok}, Failures: {total_fail}, Total: {len(archives)}")
    log("Reminder: run your master tree scanner to capture the updated library structure.")
    log("Run end.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        log("Interrupted by user.")
        sys.exit(130)
