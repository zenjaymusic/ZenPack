#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# post_sort_tidy.py — targeted fixes after sorting
# - FX\Unknown → Atmospheres (foley/field) or Melodic Loops (melodic content)
# - MIDI\Unknown → Melodic MIDI
# - REFERENCE\Unknown (and optional root) → Documentation/Script buckets
# Dry-run by default; use --commit to make changes. Logs everything.

# Author: zen

import argparse
import os
import shutil
import time
from pathlib import Path

# ==== CONFIG (edit if needed) ====
ROOT = Path(r"Z:\Audio Master\!PACKS\01 - LIBRARIES\01 - CYMATICS\Sorted_Cymatics")

FX_UNKNOWN = ROOT / r"05 - FX" / "Unknown"
FX_ATMOS   = ROOT / r"05 - FX" / "Atmospheres"

LOOPS_MELODIC = ROOT / r"02 - LOOPS" / "Melodic Loops"

MIDI_UNKNOWN = ROOT / r"04 - MIDI" / "Unknown"
MIDI_MELODIC = ROOT / r"04 - MIDI" / "Melodic MIDI"

REF_UNKNOWN   = ROOT / r"09 - REFERENCE" / "Unknown"
REF_DOCS      = ROOT / r"09 - REFERENCE" / "Documentation"
REF_SCRIPTS   = REF_DOCS / "Scripts"
REF_ASD       = REF_DOCS / "Ableton Analysis"

# Also sweep the Sorted root for strays? (tree logs / helper scripts etc.)
SWEEP_ROOT_FOR_REF = True  # set False to disable

LOG_PATH = ROOT / "post_sort_tidy_log.txt"

# Heuristics
FOLEY_KEYS   = {"walk", "walking", "footstep", "forest", "leaf", "leaves", "sand", "park", "life", "foley", "field"}
MELODIC_KEYS = {"melodic", "melody", "chord", "guitar", "piano", "keys", "pluck", "arp", "bordeaux", "champagne", "loop"}

LOG_EXTS     = {".txt", ".log", ".csv"}
SCRIPT_EXTS  = {".py"}
ASD_EXTS     = {".asd"}  # Ableton analysis sidecars
MIDI_EXTS    = {".mid", ".midi"}
AUDIO_EXTS   = {".wav", ".aiff", ".aif", ".flac", ".mp3", ".ogg", ".wma"}


def log(msg: str):
    ts = time.strftime("[%Y-%m-%d %H:%M:%S]")
    line = f"{ts} {msg}"
    print(line)
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def ensure_dirs(*paths: Path):
    for p in paths:
        p.mkdir(parents=True, exist_ok=True)


def should_go_foley(name: str, ext: str) -> bool:
    if ext not in AUDIO_EXTS:
        return False
    n = name.lower()
    return any(k in n for k in FOLEY_KEYS)


def should_go_melodic_loop(name: str, ext: str) -> bool:
    if ext not in AUDIO_EXTS:
        return False
    n = name.lower()
    # require loop-ish vibe to avoid misclassifying drum one-shots
    return ("loop" in n) or any(k in n for k in MELODIC_KEYS)


def move(src: Path, dst_dir: Path, commit: bool):
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / src.name
    if not commit:
        log(f"DRY-RUN: would move  {src}  -->  {dst}")
        return True
    try:
        if dst.exists():
            # don’t overwrite; add suffix
            base, ext = dst.stem, dst.suffix
            i = 2
            while True:
                cand = dst_dir / f"{base} ({i}){ext}"
                if not cand.exists():
                    dst = cand
                    break
                i += 1
        shutil.move(str(src), str(dst))
        log(f"MOVED: {src}  -->  {dst}")
        return True
    except Exception as e:
        log(f"ERROR moving {src}: {e}")
        return False


def sweep_fx_unknown(commit: bool) -> tuple[int, int, int]:
    moved_foley = moved_melodic = skipped = 0
    if not FX_UNKNOWN.exists():
        return (0, 0, 0)
    for p in sorted(FX_UNKNOWN.iterdir()):
        if not p.is_file():
            continue
        ext = p.suffix.lower()
        if should_go_foley(p.name, ext):
            if move(p, FX_ATMOS, commit):
                moved_foley += 1
        elif should_go_melodic_loop(p.name, ext):
            if move(p, LOOPS_MELODIC, commit):
                moved_melodic += 1
        else:
            skipped += 1
    return (moved_foley, moved_melodic, skipped)


def sweep_midi_unknown(commit: bool) -> tuple[int, int]:
    moved = skipped = 0
    if not MIDI_UNKNOWN.exists():
        return (0, 0)
    for p in sorted(MIDI_UNKNOWN.rglob("*")):
        if not p.is_file():
            continue
        if p.suffix.lower() in MIDI_EXTS:
            if move(p, MIDI_MELODIC, commit):
                moved += 1
        else:
            skipped += 1
    return (moved, skipped)


def sweep_reference(commit: bool, include_root: bool) -> tuple[int, int, int]:
    moved_scripts = moved_logs = moved_asd = 0

    targets = []
    if REF_UNKNOWN.exists():
        targets.append(REF_UNKNOWN)
    if include_root and ROOT.exists():
        targets.append(ROOT)

    ensure_dirs(REF_DOCS, REF_SCRIPTS, REF_ASD)

    for base in targets:
        for p in sorted(base.rglob("*")):
            if not p.is_file():
                continue
            ext = p.suffix.lower()
            if ext in SCRIPT_EXTS:
                if move(p, REF_SCRIPTS, commit):
                    moved_scripts += 1
            elif ext in LOG_EXTS:
                if move(p, REF_DOCS, commit):
                    moved_logs += 1
            elif ext in ASD_EXTS:
                if move(p, REF_ASD, commit):
                    moved_asd += 1

    return (moved_scripts, moved_logs, moved_asd)


def prune_empty_unknowns(commit: bool):
    # Tidy up empty Unknown folders we touched
    for p in [FX_UNKNOWN, MIDI_UNKNOWN, REF_UNKNOWN]:
        if p.exists():
            try:
                # remove recursively only if empty
                if not any(p.rglob("*")):
                    if commit:
                        p.rmdir()
                        log(f"Removed empty folder: {p}")
                    else:
                        log(f"DRY-RUN: would remove empty folder: {p}")
            except Exception:
                pass


def main():
    ap = argparse.ArgumentParser(description="Targeted post-sort tidy for Cymatics Sorted_Cymatics.")
    ap.add_argument("--commit", action="store_true", help="Actually move files (otherwise dry-run).")
    ap.add_argument("--no-root-sweep", action="store_true", help="Do not sweep Sorted root for stray logs/scripts.")
    args = ap.parse_args()

    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write("\n" + "="*80 + "\n")
        f.write(time.strftime("RUN START: %Y-%m-%d %H:%M:%S") + "\n")

    log(f"Root: {ROOT}")
    log(f"Mode: {'COMMIT' if args.commit else 'DRY-RUN'}")

    ensure_dirs(FX_ATMOS, LOOPS_MELODIC, MIDI_MELODIC, REF_DOCS, REF_SCRIPTS, REF_ASD)

    # 1) FX\Unknown → Atmospheres / Melodic Loops
    foley_moved, melodic_moved, fx_skipped = sweep_fx_unknown(commit=args.commit)
    log(f"FX Unknown: moved foley/field = {foley_moved}, moved melodic loops = {melodic_moved}, skipped (uncertain) = {fx_skipped}")

    # 2) MIDI\Unknown → Melodic MIDI
    midi_moved, midi_skipped = sweep_midi_unknown(commit=args.commit)
    log(f"MIDI Unknown: moved melodic = {midi_moved}, skipped non-MIDI = {midi_skipped}")

    # 3) REFERENCE tidying (Unknown + optionally root)
    scripts_moved, logs_moved, asd_moved = sweep_reference(commit=args.commit, include_root=SWEEP_ROOT_FOR_REF and not args.no_root_sweep)
    log(f"REFERENCE: moved scripts = {scripts_moved}, logs = {logs_moved}, Ableton .asd = {asd_moved}")

    prune_empty_unknowns(commit=args.commit)

    log("Run end.")
    print(f"\nDone. See log: {LOG_PATH}")


if __name__ == "__main__":
    main()
