import os
import shutil
import argparse
from datetime import datetime

# Default paths
ROOT_DIR = r"Z:\Audio Master\!PACKS\01 - LIBRARIES\01 - CYMATICS"
KEEP_FOLDER = "Sorted_Cymatics"
LOG_FILE = os.path.join(ROOT_DIR, "delete_source_folders_log.txt")

def log(message):
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    print(f"{timestamp} {message}")
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"{timestamp} {message}\n")

def main():
    parser = argparse.ArgumentParser(description="Delete all top-level source folders except Sorted_Cymatics.")
    parser.add_argument("--dry-run", action="store_true", help="Preview folders to be deleted without deleting them")
    args = parser.parse_args()

    log("Starting delete_source_folders.py")
    log(f"Root directory: {ROOT_DIR}")
    log(f"Keeping folder: {KEEP_FOLDER}")
    if args.dry_run:
        log("Dry run mode: No folders will be deleted.")

    if not os.path.exists(ROOT_DIR):
        log("ERROR: Root directory does not exist.")
        return

    for item in os.listdir(ROOT_DIR):
        item_path = os.path.join(ROOT_DIR, item)

        # Only handle folders, skip system/hidden and the keep folder
        if os.path.isdir(item_path) and item != KEEP_FOLDER and not item.startswith("."):
            if args.dry_run:
                log(f"Would delete folder: {item}")
            else:
                try:
                    shutil.rmtree(item_path)
                    log(f"Deleted folder: {item}")
                except Exception as e:
                    log(f"ERROR deleting {item}: {e}")

    log("Run end.")

if __name__ == "__main__":
    main()
