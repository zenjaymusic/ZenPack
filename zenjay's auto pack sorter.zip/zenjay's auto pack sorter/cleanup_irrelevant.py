import os
import argparse
import logging
from pathlib import Path

# Default junk patterns
JUNK_DIRS = {
    "__MACOSX",
    ".Spotlight-V100",
    ".Trashes",
    ".TemporaryItems",
    ".fseventsd"
}

JUNK_FILES = {
    ".DS_Store",
    "Thumbs.db",
    "desktop.ini",
    ".Icon"
}

RESOURCE_PREFIX = "._"

PREVIEW_EXTS = {".jpg", ".jpeg", ".png", ".gif"}
MEDIA_EXTS = {".mp4", ".mov", ".avi", ".mkv", ".pdf"}

def setup_logger(log_path):
    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[
            logging.FileHandler(log_path, encoding="utf-8"),
            logging.StreamHandler()
        ]
    )

def is_zero_byte(file_path):
    try:
        return os.path.getsize(file_path) == 0
    except Exception:
        return False

def cleanup_directory(root, remove_previews=False, remove_media=False, dry_run=False):
    removed_count = 0
    for dirpath, dirnames, filenames in os.walk(root, topdown=False):
        # Remove junk directories
        for dirname in list(dirnames):
            if dirname in JUNK_DIRS:
                target_dir = Path(dirpath) / dirname
                logging.info(f"Remove dir: {target_dir}")
                removed_count += 1
                if not dry_run:
                    try:
                        for sub in Path(target_dir).rglob("*"):
                            try:
                                sub.unlink()
                            except IsADirectoryError:
                                pass
                            except Exception as e:
                                logging.warning(f"Failed to remove {sub}: {e}")
                        os.rmdir(target_dir)
                    except Exception as e:
                        logging.warning(f"Failed to remove {target_dir}: {e}")
                dirnames.remove(dirname)

        # Remove junk files
        for filename in filenames:
            fpath = Path(dirpath) / filename
            if (
                filename in JUNK_FILES
                or filename.startswith(RESOURCE_PREFIX)
                or is_zero_byte(fpath)
                or (remove_previews and fpath.suffix.lower() in PREVIEW_EXTS)
                or (remove_media and fpath.suffix.lower() in MEDIA_EXTS)
            ):
                logging.info(f"Remove file: {fpath}")
                removed_count += 1
                if not dry_run:
                    try:
                        fpath.unlink()
                    except Exception as e:
                        logging.warning(f"Failed to remove {fpath}: {e}")

        # Remove empty directories
        if not os.listdir(dirpath):
            if Path(dirpath) != Path(root):
                logging.info(f"Remove empty dir: {dirpath}")
                removed_count += 1
                if not dry_run:
                    try:
                        os.rmdir(dirpath)
                    except Exception as e:
                        logging.warning(f"Failed to remove {dirpath}: {e}")

    return removed_count

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Cleanup irrelevant/junk files and folders.")
    parser.add_argument(
        "--root",
        type=str,
        default=r"Z:\Audio Master\!PACKS\01 - LIBRARIES\01 - CYMATICS",
        help="Root folder to clean."
    )
    parser.add_argument("--remove-previews", action="store_true", help="Remove image previews (jpg, png, etc.)")
    parser.add_argument("--remove-media", action="store_true", help="Remove PDFs/videos")
    parser.add_argument("--dry-run", action="store_true", help="Preview without deleting")
    args = parser.parse_args()

    log_path = Path(args.root) / "cleanup_log.txt"
    setup_logger(log_path)

    logging.info(f"Starting cleanup in: {args.root}")
    removed = cleanup_directory(args.root, args.remove_previews, args.remove_media, args.dry_run)
    logging.info(f"Cleanup finished. Items removed: {removed}")
    logging.info("Run your master tree scanner to capture the updated structure.")
