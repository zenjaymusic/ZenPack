#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
structure_sort.py  (ZEN edition, COPY MODE ONLY)
------------------------------------------------
Scans the library root and **copies** files into a locked, canonical folder
structure with per-category "Unknown" buckets. Includes a dedicated DRUMS/808s
folder (not nested under Kicks).

- COPY mode only (originals remain)
- UTF-8 console guard (Windows-safe)
- ASCII arrows in logs
- Skips duplicates (doesn't overwrite existing destination files)
- Keyword + extension classification with conservative fallbacks
- Idempotent runs

DEFAULTS
--------
ROOT: Z:/Audio Master/!PACKS/01 - LIBRARIES/01 - CYMATICS
OUT : <ROOT>/Sorted_Cymatics

USAGE
-----
python structure_sort.py
python structure_sort.py --dry-run
python structure_sort.py --root "D:/Libs/SAMPLES" --out "D:/Libs/SAMPLES/Sorted"

Author: zen
"""

import argparse
import os
import shutil
import time
from pathlib import Path
from typing import Tuple

# --- make console UTF-8 friendly on Windows & keep ASCII arrows to be safe ---
import sys
for _s in (getattr(sys, "stdout", None), getattr(sys, "stderr", None)):
    try:
        if _s and hasattr(_s, "reconfigure"):
            _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

ARROW = "->"

# ======== DEFAULT PATHS ========
DEFAULT_ROOT = r"Z:/Audio Master/!PACKS/01 - LIBRARIES/01 - CYMATICS"
DEFAULT_OUT  = None  # if None, will use <ROOT>/Sorted_Cymatics

SCRIPT_DIR = Path(__file__).resolve().parent
LOG_PATH = SCRIPT_DIR / "structure_sort_log.txt"


def log(msg: str, *, also_file: bool = True) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    if also_file:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")


# ======== CANONICAL STRUCTURE (LOCKED) ========
# Category folder names
CAT = {
    "DRUMS": "01 - DRUMS",
    "LOOPS": "02 - LOOPS",
    "ONE_SHOTS": "03 - ONE SHOTS",
    "MIDI": "04 - MIDI",
    "FX": "05 - FX",
    "SERUM": "06 - SERUM PRESETS",
    "PRESETS_OTHER": "07 - OTHER PRESETS",
    "PROJECTS": "08 - PROJECT FILES",
    "REFERENCE": "09 - REFERENCE",
}

# Subfolders for each category (Title Case). Include an "Unknown" bucket.
# DRUMS now includes a top-level "808s" sibling of Kicks.
SUBFOLDERS = {
    CAT["DRUMS"]: [
        "808s", "Kicks", "Snares", "Claps", "Hi-Hats", "Cymbals", "Percussion", "Toms", "FX Drums", "Unknown"
    ],
    CAT["LOOPS"]: [
        "Melodic Loops", "Drum Loops", "Bass Loops", "FX Loops", "Unknown"
    ],
    CAT["ONE_SHOTS"]: [
        "Bass", "Piano", "Guitar", "Synth", "Strings", "Brass", "Woodwinds", "Vocal One Shots", "FX One Shots", "Unknown"
    ],
    CAT["MIDI"]: [
        "Melodic MIDI", "Drum MIDI", "Bass MIDI", "Unknown"
    ],
    CAT["FX"]: [
        "Impacts", "Risers", "Downlifters", "Uplifters", "Sweeps", "Atmospheres", "Textures", "Misc FX", "Unknown"
    ],
    CAT["SERUM"]: [
        "Bass Presets", "Lead Presets", "Pad Presets", "Pluck Presets", "FX Presets", "Unknown"
    ],
    CAT["PRESETS_OTHER"]: [
        "Massive Presets", "Sylenth Presets", "Vital Presets", "Other Synth Presets", "Unknown"
    ],
    CAT["PROJECTS"]:[
        "Ableton Projects", "FL Studio Projects", "Other DAW Projects", "Unknown"
    ],
    CAT["REFERENCE"]:[
        "Demo Tracks", "Artwork", "Documentation", "Unknown"
    ]
}

# ======== EXTENSIONS ========
AUDIO_EXT = {".wav", ".aiff", ".aif", ".flac", ".mp3", ".ogg", ".wma"}
MIDI_EXT  = {".mid", ".midi"}

# Presets (approximate)
SERUM_EXT = {".fxp", ".fxb"}  # Serum single/bank
MASSIVE_EXT = {".nmsv", ".ksd"}
VITAL_EXT = {".vitalpreset", ".vital"}  # Vital single/bank

# Reference media
ART_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".svg"}
DOC_EXT = {".pdf", ".txt", ".md"}
DEMO_AUDIO_EXT = AUDIO_EXT  # demo tracks are audio

# Projects
ABLETON_EXT = {".als"}
FL_EXT      = {".flp"}
OTHER_DAW_EXT = {".logicx", ".band", ".cpr", ".reaperproject"}  # placeholders


def _kw(*items): return {s.lower() for s in items}

KW = {
    "drums": {
        "kicks": _kw("kick", "kck", "sub kick"),
        "snares": _kw("snare"),
        "claps": _kw("clap"),
        "hihats": _kw("hihat", "hi-hat", "hat", "closed hat", "open hat"),
        "cymbals": _kw("ride", "crash", "cymbal"),
        "perc": _kw("perc", "percussion", "bongo", "conga", "shaker", "tamb", "tambourine", "cowbell", "clave", "rim"),
        "toms": _kw("tom"),
        "fxdrums": _kw("drum fx", "drumfx", "fill", "drum fill", "roll"),
        "eightoh": _kw("808"),  # explicit 808 detector
    },
    "loops": {
        "melodic": _kw("melodic loop", "melody loop", "arp loop", "chord loop", "guitar loop", "piano loop", "synth loop", "pluck loop"),
        "drum": _kw("drum loop", "drumloop", "top loop", "tops"),
        "bass": _kw("bass loop", "808 loop", "sub loop"),
        "fx": _kw("fx loop", "texture loop", "atmo loop", "atmos loop"),
    },
    "oneshots": {
        "bass": _kw("bass one shot", "bass shot", "808", "sub"),
        "piano": _kw("piano one shot", "keys one shot", "keys"),
        "guitar": _kw("guitar one shot"),
        "synth": _kw("synth one shot", "pluck", "lead shot"),
        "strings": _kw("string one shot", "violin", "cello"),
        "brass": _kw("brass one shot", "trumpet", "trombone", "horn"),
        "woodwinds": _kw("flute", "clarinet", "sax", "saxophone"),
        "vocal": _kw("vocal one shot", "vox one shot", "vox"),
        "fx": _kw("fx one shot", "shot fx"),
    },
    "fx": {
        "impacts": _kw("impact", "hit"),
        "risers": _kw("riser", "build"),
        "downlifters": _kw("downlifter", "downlift", "down sweep"),
        "uplifters": _kw("uplifter", "uplift", "up sweep"),
        "sweeps": _kw("sweep"),
        "atmos": _kw("atmos", "atmosphere", "ambience", "texture", "drone", "pad"),
        "textures": _kw("texture", "granular"),
    },
    "midi": {
        "drum": _kw("drum midi", "hi-hat midi", "hihat midi"),
        "bass": _kw("bass midi", "808 midi"),
        "melodic": _kw("midi", "chord", "melody", "arp"),
    },
    "presets": {
        "serum": _kw("serum"),
        "massive": _kw("massive"),
        "sylenth": _kw("sylenth"),
        "vital": _kw("vital"),
        "bass": _kw("bass"),
        "lead": _kw("lead"),
        "pad": _kw("pad"),
        "pluck": _kw("pluck"),
        "fx": _kw("fx"),
    },
    "projects": {
        "ableton": _kw("ableton", "als"),
        "fl": _kw("fl", "flp", "fl studio"),
    },
    "reference": {
        "demo": _kw("demo", "preview"),
        "art": _kw("cover", "art", "artwork"),
        "doc": _kw("guide", "readme", "license", "documentation"),
    }
}


def normalise(s: str) -> str:
    return s.lower().replace("_", " ").replace("-", " ")


def ensure_structure(out_root: Path) -> None:
    """Create the locked folder structure with Unknown buckets."""
    for cat, subs in SUBFOLDERS.items():
        base = out_root / cat
        base.mkdir(parents=True, exist_ok=True)
        for sub in subs:
            (base / sub).mkdir(parents=True, exist_ok=True)


def classify(path: Path) -> Tuple[str, str]:
    """
    Return (category_folder_name, subfolder_name) for destination.
    Falls back to the category's 'Unknown' when we can't decide.
    """
    name = normalise(path.stem)
    ext = path.suffix.lower()

    # MIDI first (exact by extension)
    if ext in MIDI_EXT:
        if any(k in name for k in KW["midi"]["drum"]):
            return CAT["MIDI"], "Drum MIDI"
        if any(k in name for k in KW["midi"]["bass"]):
            return CAT["MIDI"], "Bass MIDI"
        if any(k in name for k in KW["midi"]["melodic"]):
            return CAT["MIDI"], "Melodic MIDI"
        return CAT["MIDI"], "Unknown"

    # Projects
    if ext in ABLETON_EXT:
        return CAT["PROJECTS"], "Ableton Projects"
    if ext in FL_EXT:
        return CAT["PROJECTS"], "FL Studio Projects"
    if ext in OTHER_DAW_EXT:
        return CAT["PROJECTS"], "Other DAW Projects"

    # Presets (heuristic by ext + keywords in path/name)
    if ext in SERUM_EXT or "serum" in name:
        if any(k in name for k in KW["presets"]["bass"]):
            return CAT["SERUM"], "Bass Presets"
        if any(k in name for k in KW["presets"]["lead"]):
            return CAT["SERUM"], "Lead Presets"
        if any(k in name for k in KW["presets"]["pad"]):
            return CAT["SERUM"], "Pad Presets"
        if any(k in name for k in KW["presets"]["pluck"]):
            return CAT["SERUM"], "Pluck Presets"
        if any(k in name for k in KW["presets"]["fx"]):
            return CAT["SERUM"], "FX Presets"
        return CAT["SERUM"], "Unknown"

    if ext in MASSIVE_EXT or "massive" in name:
        return CAT["PRESETS_OTHER"], "Massive Presets"
    if "sylenth" in path.as_posix().lower():
        return CAT["PRESETS_OTHER"], "Sylenth Presets"
    if ext in VITAL_EXT or "vital" in name:
        return CAT["PRESETS_OTHER"], "Vital Presets"

    # Reference (art/docs/demo), if not caught by above
    if ext in ART_EXT:
        return CAT["REFERENCE"], "Artwork"
    if ext in DOC_EXT:
        return CAT["REFERENCE"], "Documentation"
    if ext in DEMO_AUDIO_EXT and ("demo" in name or "preview" in name):
        return CAT["REFERENCE"], "Demo Tracks"

    # Audio (WAV/AIFF/MP3/etc.) → Drums/Loops/One Shots/FX by keywords
    if ext in AUDIO_EXT:
        # Explicit 808 check FIRST to route to DRUMS/808s
        if "808" in name:
            return CAT["DRUMS"], "808s"

        # Drums
        if any(k in name for k in KW["drums"]["kicks"]):
            return CAT["DRUMS"], "Kicks"
        if any(k in name for k in KW["drums"]["snares"]):
            return CAT["DRUMS"], "Snares"
        if any(k in name for k in KW["drums"]["claps"]):
            return CAT["DRUMS"], "Claps"
        if any(k in name for k in KW["drums"]["hihats"]):
            return CAT["DRUMS"], "Hi-Hats"
        if any(k in name for k in KW["drums"]["cymbals"]):
            return CAT["DRUMS"], "Cymbals"
        if any(k in name for k in KW["drums"]["perc"]):
            return CAT["DRUMS"], "Percussion"
        if any(k in name for k in KW["drums"]["toms"]):
            return CAT["DRUMS"], "Toms"
        if any(k in name for k in KW["drums"]["fxdrums"]):
            return CAT["DRUMS"], "FX Drums"

        # Loops (must contain 'loop' or look like one)
        if "loop" in name or "loops" in name:
            if any(k in name for k in KW["loops"]["drum"]):
                return CAT["LOOPS"], "Drum Loops"
            if any(k in name for k in KW["loops"]["bass"]):
                return CAT["LOOPS"], "Bass Loops"
            if any(k in name for k in KW["loops"]["fx"]):
                return CAT["LOOPS"], "FX Loops"
            return CAT["LOOPS"], "Melodic Loops"

        # One shots (non-drums)
        if "one shot" in name or "oneshot" in name or "shot" in name:
            if any(k in name for k in KW["oneshots"]["bass"]):
                return CAT["ONE_SHOTS"], "Bass"
            if any(k in name for k in KW["oneshots"]["piano"]):
                return CAT["ONE_SHOTS"], "Piano"
            if any(k in name for k in KW["oneshots"]["guitar"]):
                return CAT["ONE_SHOTS"], "Guitar"
            if any(k in name for k in KW["oneshots"]["synth"]):
                return CAT["ONE_SHOTS"], "Synth"
            if any(k in name for k in KW["oneshots"]["strings"]):
                return CAT["ONE_SHOTS"], "Strings"
            if any(k in name for k in KW["oneshots"]["brass"]):
                return CAT["ONE_SHOTS"], "Brass"
            if any(k in name for k in KW["oneshots"]["woodwinds"]):
                return CAT["ONE_SHOTS"], "Woodwinds"
            if any(k in name for k in KW["oneshots"]["vocal"]):
                return CAT["ONE_SHOTS"], "Vocal One Shots"
            if any(k in name for k in KW["oneshots"]["fx"]):
                return CAT["ONE_SHOTS"], "FX One Shots"
            return CAT["ONE_SHOTS"], "Unknown"

        # FX (generic catch)
        if any(k in name for k in KW["fx"]["impacts"]):
            return CAT["FX"], "Impacts"
        if any(k in name for k in KW["fx"]["risers"]):
            return CAT["FX"], "Risers"
        if any(k in name for k in KW["fx"]["downlifters"]):
            return CAT["FX"], "Downlifters"
        if any(k in name for k in KW["fx"]["uplifters"]):
            return CAT["FX"], "Uplifters"
        if any(k in name for k in KW["fx"]["sweeps"]):
            return CAT["FX"], "Sweeps"
        if any(k in name for k in KW["fx"]["atmos"]):
            return CAT["FX"], "Atmospheres"
        if any(k in name for k in KW["fx"]["textures"]):
            return CAT["FX"], "Textures"
        return CAT["FX"], "Unknown"

    # If we reach here, drop to REFERENCE/Unknown to avoid losing files
    return CAT["REFERENCE"], "Unknown"


def copy_if_missing(src: Path, dst: Path, *, dry_run: bool) -> Tuple[bool, str]:
    """Copy src to dst if dst doesn't exist. Returns (copied, message)."""
    try:
        if dst.exists():
            return False, "exists"
        if dry_run:
            return True, "DRY-RUN (not copied)"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        return True, "copied"
    except Exception as e:
        return False, f"error: {e}"


def main() -> int:
    parser = argparse.ArgumentParser(description="Copy files into locked structure with Unknown buckets.")
    parser.add_argument("--root", default=DEFAULT_ROOT, help=f"Root to scan. Default: {DEFAULT_ROOT}")
    parser.add_argument("--out", default=DEFAULT_OUT, help="Destination root. Default: <ROOT>/Sorted_Cymatics")
    parser.add_argument("--dry-run", action="store_true", help="Preview actions without copying.")
    args = parser.parse_args()

    root = Path(args.root).expanduser()
    out_root = Path(args.out).expanduser() if args.out else (root / "Sorted_Cymatics")

    # Log header
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write("\n" + "="*80 + "\n")
        f.write(time.strftime("RUN START: %Y-%m-%d %H:%M:%S") + "\n")
        f.write(f"ROOT: {root}\nOUT: {out_root}\nDRY_RUN: {args.dry_run}\n")
        f.write("="*80 + "\n")

    log("Starting structure_sort.py (COPY mode)")
    log(f"Root: {root}")
    log(f"Out : {out_root}")

    if not root.exists():
        log("ERROR: Root does not exist.")
        return 2

    ensure_structure(out_root)

    files_scanned = 0
    files_copied = 0
    files_skipped = 0
    files_failed = 0

    # Walk the tree
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        # Never re-copy from the output tree itself
        try:
            if out_root in p.parents:
                continue
        except Exception:
            pass

        files_scanned += 1
        cat, sub = classify(p)
        rel_name = p.name  # keep original filename
        dest = out_root / cat / sub / rel_name

        copied, msg = copy_if_missing(p, dest, dry_run=args.dry_run)
        if copied:
            files_copied += 1
            log(f"COPY {ARROW} {p}  ==>  {dest}  ({msg})")
        else:
            if msg == "exists":
                files_skipped += 1
                log(f"SKIP (exists) {ARROW} {dest}")
            else:
                files_failed += 1
                log(f"FAIL {ARROW} {p}  ({msg})")

    # Summary
    log("-" * 60)
    log(f"Scanned files : {files_scanned}")
    log(f"Copied files  : {files_copied}")
    log(f"Skipped (exist): {files_skipped}")
    log(f"Failed copies : {files_failed}")
    log("Run end.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        log("Interrupted by user.")
        raise SystemExit(130)
