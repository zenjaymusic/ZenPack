#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# File tree logger with depth limit (ASCII-safe)

import sys, os, argparse
from pathlib import Path
from datetime import datetime

# UTF-8 safe stdout/stderr (Windows)
for _s in (getattr(sys, "stdout", None), getattr(sys, "stderr", None)):
    try:
        if _s and hasattr(_s, "reconfigure"):
            _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

def scan_directory(root_dir: Path, log_file: Path, max_depth: int):
    with open(log_file, "w", encoding="utf-8") as log:
        log.write(f"File Tree Log - Generated {datetime.now()}\n")
        log.write(f"Root: {root_dir}\n")
        log.write(f"Max Depth: {max_depth}\n")
        log.write("=" * 60 + "\n\n")

        for current_path, dirs, files in os.walk(root_dir):
            rel = Path(current_path).relative_to(root_dir)
            depth = 0 if rel == Path(".") else len(rel.parts)

            if max_depth >= 0 and depth > max_depth:
                # don't recurse deeper
                dirs[:] = []
                continue

            # sort for stable, readable output
            dirs.sort(key=str.lower)
            files.sort(key=str.lower)

            indent = "    " * depth
            log.write(f"{indent}[DIR] {rel if rel != Path('.') else root_dir.name}\n")
            for f in files:
                log.write(f"{indent}    {f}\n")
            log.write("\n")

    print(f"File tree written to: {log_file}")

def main():
    ap = argparse.ArgumentParser(description="Write a plain text file tree.")
    ap.add_argument("--root", required=True, help="Root folder to scan.")
    ap.add_argument("--max-depth", type=int, default=-1, help="Maximum folder depth (-1 = unlimited).")
    args = ap.parse_args()

    root_dir = Path(args.root)
    if not root_dir.exists():
        print(f"ERROR: Root path does not exist: {root_dir}")
        sys.exit(2)

    log_file = root_dir / "tree_log.txt"
    scan_directory(root_dir, log_file, args.max_depth)

if __name__ == "__main__":
    main()
