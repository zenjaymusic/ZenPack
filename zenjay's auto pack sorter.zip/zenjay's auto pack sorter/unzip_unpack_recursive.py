
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
unzip_unpack_recursive.py  (ZEN edition)
----------------------------------------
Recursively extracts ALL .zip/.rar archives under a source root until none remain.
Accepts a folder OR a single archive file as --source. Double-click friendly with defaults.

Features
- Auto-detect 7-Zip (handles .zip + .rar). Falls back to stdlib for .zip.
- Smart folder handling: if archive has a single top-level folder, extract directly into --dest;
  otherwise extract into --dest/<archive-name>.
- Multi-pass loop: scan → extract → rescan, until no archives remain (or --max-passes reached).
- Idempotent-ish: skips if output folder already exists unless --force is provided.
- Robust UTF-8 logging + live terminal output. Graceful on errors; continues.
- Same defaults as the single-pass script.

Usage
-----
  python unzip_unpack_recursive.py
  python unzip_unpack_recursive.py --dry-run
  python unzip_unpack_recursive.py --source "Z:/.../CYMATICS.rar"
  python unzip_unpack_recursive.py --source "Z:/.../CYMATICS" --dest "Z:/.../CYMATICS"
  python unzip_unpack_recursive.py --max-passes 10 --force

Author: zen
"""

import argparse
import os
import sys
import subprocess
import time
import zipfile
from pathlib import Path
from typing import Optional, Tuple, List, Set

# ======== DEFAULTS (edit if needed) ========
DEFAULT_SOURCE = r"Z:/Audio Master/!PACKS/01 - LIBRARIES/01 - CYMATICS"
DEFAULT_DEST   = r"Z:/Audio Master/!PACKS/01 - LIBRARIES/01 - CYMATICS"

SCRIPT_DIR = Path(__file__).resolve().parent
LOG_PATH = SCRIPT_DIR / "unzip_unpack_recursive_log.txt"


def log(msg: str, *, also_file: bool = True) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    if also_file:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")


def find_sevenzip() -> Optional[Path]:
    """Return a Path to 7z.exe if available, else None."""
    try_candidates = [
        Path(r"C:\Program Files\7-Zip\7z.exe"),
        Path(r"C:\Program Files (x86)\7-Zip\7z.exe"),
    ]
    # PATH lookup
    for dir_ in os.environ.get("PATH", "").split(os.pathsep):
        if dir_:
            try_candidates.append(Path(dir_) / "7z.exe")
    for p in try_candidates:
        try:
            if p.exists():
                return p.resolve()
        except Exception:
            continue
    return None


def zip_has_single_top_dir(zf: zipfile.ZipFile) -> Tuple[bool, Optional[str]]:
    """Detect if a .zip has exactly one top-level directory; return (True, 'dirname') if so."""
    names = [n for n in zf.namelist() if n and not n.endswith('/')]
    top_levels = set()
    for n in names:
        top = n.split('/', 1)[0]
        if top:
            top_levels.add(top)
    # If there are no files but there is exactly one directory, still treat as single dir
    if not names:
        dir_entries = [n for n in zf.namelist() if n.endswith('/')]
        tl = set(d.split('/', 1)[0] for d in dir_entries if d)
        if len(tl) == 1:
            only = next(iter(tl))
            return True, only
        return False, None

    if len(top_levels) == 1:
        only = next(iter(top_levels))
        # Confirm it's actually a directory (has children)
        if any(m.startswith(only + "/") for m in zf.namelist() if m != only):
            return True, only
    return False, None


def sevenzip_list_toplevels(sevenzip: Path, archive: Path) -> Optional[set]:
    """Use 7z to list entries and compute top-level names. Returns set or None on failure."""
    try:
        result = subprocess.run([str(sevenzip), "l", "-ba", str(archive)],
                                capture_output=True, text=True, encoding="utf-8", errors="ignore")
        if result.returncode != 0:
            return None
        tops = set()
        for line in result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            path = parts[-1] if parts else ""
            if not path or path in (".", ".."):
                continue
            path = path.replace("\\", "/")
            top = path.split("/", 1)[0]
            if top:
                tops.add(top)
        return tops or None
    except Exception:
        return None


def extract_with_7z(sevenzip: Path, archive: Path, dest: Path) -> Tuple[bool, str]:
    try:
        dest.mkdir(parents=True, exist_ok=True)
        proc = subprocess.run([str(sevenzip), "x", "-y", f"-o{str(dest)}", str(archive), "-bso0", "-bsp0"],
                              capture_output=True, text=True, encoding="utf-8", errors="ignore")
        if proc.returncode == 0:
            return True, "OK (7z)"
        return False, f"7z failed (code {proc.returncode})"
    except Exception as e:
        return False, f"7z error: {e}"


def extract_zip_stdlib(archive: Path, dest: Path) -> Tuple[bool, str]:
    try:
        dest.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(archive, 'r') as zf:
            zf.extractall(dest)
        return True, "OK (zipfile)"
    except Exception as e:
        return False, f"zipfile error: {e}"


def already_extracted(dest_root: Path, archive: Path) -> bool:
    """Treat as extracted if dest/<archive-name> exists. We keep it simple for speed."""
    base = archive.stem
    return (dest_root / base).exists()


def decide_extract_dest(archive: Path, dest_root: Path, sevenzip: Optional[Path]) -> Tuple[Path, bool, Optional[str]]:
    """Return (extract_to, single_dir, inner_name)."""
    ext = archive.suffix.lower()
    single_dir = False
    inner = None

    if sevenzip:
        tops = sevenzip_list_toplevels(sevenzip, archive)
        if tops and len(tops) == 1:
            inner = next(iter(tops))
            single_dir = True
    elif ext == ".zip":
        try:
            with zipfile.ZipFile(archive, 'r') as zf:
                single_dir, inner = zip_has_single_top_dir(zf)
        except Exception:
            pass

    extract_to = dest_root if single_dir else (dest_root / archive.stem)
    return extract_to, single_dir, inner


def discover_archives(source: Path) -> List[Path]:
    """Return a list of archives. Accepts either a single file or a folder (recursive)."""
    if source.is_file():
        return [source] if source.suffix.lower() in (".zip", ".rar") else []
    if not source.exists():
        return []
    archives: List[Path] = []
    for p in source.rglob("*"):
        if p.is_file() and p.suffix.lower() in (".zip", ".rar"):
            archives.append(p)
    archives.sort()
    return archives


def main() -> int:
    parser = argparse.ArgumentParser(description="Recursively extract all .zip/.rar under a source until none remain.")
    parser.add_argument("--source", default=DEFAULT_SOURCE,
                        help=f"Folder OR single archive (.zip/.rar). Default: {DEFAULT_SOURCE}")
    parser.add_argument("--dest", default=DEFAULT_DEST,
                        help=f"Destination root for extracted content. Default: {DEFAULT_DEST}")
    parser.add_argument("--dry-run", action="store_true", help="List actions without extracting.")
    parser.add_argument("--force", action="store_true", help="Re-extract even if destination appears to exist.")
    parser.add_argument("--max-passes", type=int, default=20, help="Safety cap on recursive passes (default: 20).")
    args = parser.parse_args()

    source = Path(args.source).expanduser()
    dest = Path(args.dest).expanduser()

    # Log header
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write("\n" + "="*80 + "\n")
        f.write(time.strftime("RUN START: %Y-%m-%d %H:%M:%S") + "\n")
        f.write(f"SOURCE: {source}\nDEST: {dest}\nDRY_RUN: {args.dry_run}\nFORCE: {args.force}\nMAX_PASSES: {args.max_passes}\n")
        f.write("="*80 + "\n")

    log("Starting unzip_unpack_recursive.py")
    log(f"Source: {source}")
    log(f"Destination: {dest}")

    if not source.exists():
        log("ERROR: Source path does not exist.")
        return 2

    dest.mkdir(parents=True, exist_ok=True)

    sevenzip = find_sevenzip()
    if sevenzip:
        log(f"7-Zip found at: {sevenzip}")
    else:
        log("7-Zip NOT found. .rar archives will FAIL; .zip will still be handled.")
        log("Tip: install via 'winget install -e --id 7zip.7zip' or 'choco install 7zip' then re-run.")

    # Recursive multi-pass loop
    total_success = 0
    total_fail = 0
    for pass_no in range(1, args.max_passes + 1):
        log("-" * 60)
        log(f"PASS {pass_no} — scanning for .zip/.rar")
        archives = discover_archives(source)
        if not archives:
            log("No archives found. Recursion complete.")
            break

        pass_success = 0
        pass_fail = 0
        for i, arc in enumerate(archives, 1):
            log(f"[Pass {pass_no} | {i}/{len(archives)}] {arc}")
            if (not args.force) and already_extracted(dest, arc):
                log("  Skipped (already extracted)")
                continue

            extract_to, single_dir, inner = decide_extract_dest(arc, dest, sevenzip)
            if args.dry_run:
                log(f"  DRY-RUN: would extract to '{extract_to}' (single_dir={single_dir}, inner='{inner}')")
                pass_success += 1
                continue

            if sevenzip:
                ok, msg = extract_with_7z(sevenzip, arc, extract_to)
            elif arc.suffix.lower() == ".zip":
                ok, msg = extract_zip_stdlib(arc, extract_to)
            else:
                ok, msg = False, "No 7-Zip available for .rar; install 7-Zip"

            if ok:
                pass_success += 1
                total_success += 1
                log(f"  SUCCESS: {msg}")
            else:
                pass_fail += 1
                total_fail += 1
                log(f"  FAIL: {msg}")

        log(f"PASS {pass_no} summary — success: {pass_success}, fail: {pass_fail}, total: {len(archives)}")

        # If in dry-run, just do one pass (show what's there now)
        if args.dry_run:
            log("Dry-run mode: stopping after one pass.")
            break

        # Rescan to see if new archives appeared (nested). If none changed (no success this pass), stop to avoid loops.
        if pass_success == 0:
            log("No progress in this pass; stopping to avoid infinite loop.")
            break

    log("-" * 60)
    log(f"Completed recursive extraction. Total success: {total_success}, Total failures: {total_fail}")
    log("Reminder: run your master tree scanner to capture the updated library structure.")
    log("Run end.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        log("Interrupted by user.")
        sys.exit(130)
