#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
structure_sort_move.py  (ZEN edition, MOVE MODE)
-------------------------------------------------
Moves files from your library root into the locked Sorted structure
(with Unknown buckets). Includes DRUMS/808s as a top-level sibling of Kicks.

- MOVE mode (originals are moved)
- UTF-8 console guard (Windows-safe)
- ASCII arrows in logs
- Duplicate policy: --on-duplicate skip|rename|overwrite (default: skip)
- Skips files already under the output tree
- Prunes empty source directories after moving
"""

import argparse
import os
import shutil
import time
from pathlib import Path
from typing import Tuple

# --- Windows console: make stdout/stderr UTF-8 friendly; still use ASCII arrows ---
import sys
for _s in (getattr(sys, "stdout", None), getattr(sys, "stderr", None)):
    try:
        if _s and hasattr(_s, "reconfigure"):
            _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

ARROW = "->"

# ======== DEFAULT PATHS ========
DEFAULT_ROOT = r"Z:/Audio Master/!PACKS/01 - LIBRARIES/01 - CYMATICS"
DEFAULT_OUT  = None  # if None, use <ROOT>/Sorted_Cymatics

SCRIPT_DIR = Path(__file__).resolve().parent
LOG_PATH = SCRIPT_DIR / "structure_sort_move_log.txt"

def log(msg: str, *, also_file: bool = True) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    if also_file:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")

# ======== LOCKED STRUCTURE ========
CAT = {
    "DRUMS": "01 - DRUMS",
    "LOOPS": "02 - LOOPS",
    "ONE_SHOTS": "03 - ONE SHOTS",
    "MIDI": "04 - MIDI",
    "FX": "05 - FX",
    "SERUM": "06 - SERUM PRESETS",
    "PRESETS_OTHER": "07 - OTHER PRESETS",
    "PROJECTS": "08 - PROJECT FILES",
    "REFERENCE": "09 - REFERENCE",
}

SUBFOLDERS = {
    CAT["DRUMS"]: [
        "808s", "Kicks", "Snares", "Claps", "Hi-Hats", "Cymbals", "Percussion", "Toms", "FX Drums", "Unknown"
    ],
    CAT["LOOPS"]: [
        "Melodic Loops", "Drum Loops", "Bass Loops", "FX Loops", "Unknown"
    ],
    CAT["ONE_SHOTS"]: [
        "Bass", "Piano", "Guitar", "Synth", "Strings", "Brass", "Woodwinds", "Vocal One Shots", "FX One Shots", "Unknown"
    ],
    CAT["MIDI"]: [
        "Melodic MIDI", "Drum MIDI", "Bass MIDI", "Unknown"
    ],
    CAT["FX"]: [
        "Impacts", "Risers", "Downlifters", "Uplifters", "Sweeps", "Atmospheres", "Textures", "Misc FX", "Unknown"
    ],
    CAT["SERUM"]: [
        "Bass Presets", "Lead Presets", "Pad Presets", "Pluck Presets", "FX Presets", "Unknown"
    ],
    CAT["PRESETS_OTHER"]: [
        "Massive Presets", "Sylenth Presets", "Vital Presets", "Other Synth Presets", "Unknown"
    ],
    CAT["PROJECTS"]: [
        "Ableton Projects", "FL Studio Projects", "Other DAW Projects", "Unknown"
    ],
    CAT["REFERENCE"]: [
        "Demo Tracks", "Artwork", "Documentation", "Unknown"
    ],
}

# ======== EXTENSIONS ========
AUDIO_EXT = {".wav", ".aiff", ".aif", ".flac", ".mp3", ".ogg", ".wma"}
MIDI_EXT  = {".mid", ".midi"}

SERUM_EXT = {".fxp", ".fxb"}
MASSIVE_EXT = {".nmsv", ".ksd"}
VITAL_EXT = {".vitalpreset", ".vital"}

ART_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".svg"}
DOC_EXT = {".pdf", ".txt", ".md"}
DEMO_AUDIO_EXT = AUDIO_EXT

ABLETON_EXT = {".als"}
FL_EXT      = {".flp"}
OTHER_DAW_EXT = {".logicx", ".band", ".cpr", ".reaperproject"}  # placeholders

def _kw(*items): return {s.lower() for s in items}

KW = {
    "drums": {
        "kicks": _kw("kick", "kck", "sub kick"),
        "snares": _kw("snare"),
        "claps": _kw("clap"),
        "hihats": _kw("hihat", "hi-hat", "hat", "closed hat", "open hat"),
        "cymbals": _kw("ride", "crash", "cymbal"),
        "perc": _kw("perc", "percussion", "bongo", "conga", "shaker", "tamb", "tambourine", "cowbell", "clave", "rim"),
        "toms": _kw("tom"),
        "fxdrums": _kw("drum fx", "drumfx", "fill", "drum fill", "roll"),
    },
    "loops": {
        "melodic": _kw("melodic loop", "melody loop", "arp loop", "chord loop", "guitar loop", "piano loop", "synth loop", "pluck loop"),
        "drum": _kw("drum loop", "drumloop", "top loop", "tops"),
        "bass": _kw("bass loop", "808 loop", "sub loop"),
        "fx": _kw("fx loop", "texture loop", "atmo loop", "atmos loop"),
    },
    "oneshots": {
        "bass": _kw("bass one shot", "bass shot", "808", "sub"),
        "piano": _kw("piano one shot", "keys one shot", "keys"),
        "guitar": _kw("guitar one shot"),
        "synth": _kw("synth one shot", "pluck", "lead shot"),
        "strings": _kw("string one shot", "violin", "cello"),
        "brass": _kw("brass one shot", "trumpet", "trombone", "horn"),
        "woodwinds": _kw("flute", "clarinet", "sax", "saxophone"),
        "vocal": _kw("vocal one shot", "vox one shot", "vox"),
        "fx": _kw("fx one shot", "shot fx"),
    },
    "fx": {
        "impacts": _kw("impact", "hit"),
        "risers": _kw("riser", "build"),
        "downlifters": _kw("downlifter", "downlift", "down sweep"),
        "uplifters": _kw("uplifter", "uplift", "up sweep"),
        "sweeps": _kw("sweep"),
        "atmos": _kw("atmos", "atmosphere", "ambience", "texture", "drone", "pad"),
        "textures": _kw("texture", "granular"),
    },
    "midi": {
        "drum": _kw("drum midi", "hi-hat midi", "hihat midi"),
        "bass": _kw("bass midi", "808 midi"),
        "melodic": _kw("midi", "chord", "melody", "arp"),
    },
    "presets": {
        "serum": _kw("serum"),
        "massive": _kw("massive"),
        "sylenth": _kw("sylenth"),
        "vital": _kw("vital"),
        "bass": _kw("bass"),
        "lead": _kw("lead"),
        "pad": _kw("pad"),
        "pluck": _kw("pluck"),
        "fx": _kw("fx"),
    },
    "projects": {
        "ableton": _kw("ableton", "als"),
        "fl": _kw("fl", "flp", "fl studio"),
    },
    "reference": {
        "demo": _kw("demo", "preview"),
        "art": _kw("cover", "art", "artwork"),
        "doc": _kw("guide", "readme", "license", "documentation"),
    }
}

def normalise(s: str) -> str:
    return s.lower().replace("_", " ").replace("-", " ")

def ensure_structure(out_root: Path) -> None:
    for cat, subs in SUBFOLDERS.items():
        base = out_root / cat
        base.mkdir(parents=True, exist_ok=True)
        for sub in subs:
            (base / sub).mkdir(parents=True, exist_ok=True)

def classify(path: Path) -> Tuple[str, str]:
    name = normalise(path.stem)
    ext = path.suffix.lower()

    # MIDI
    if ext in MIDI_EXT:
        if any(k in name for k in KW["midi"]["drum"]):   return CAT["MIDI"], "Drum MIDI"
        if any(k in name for k in KW["midi"]["bass"]):   return CAT["MIDI"], "Bass MIDI"
        if any(k in name for k in KW["midi"]["melodic"]):return CAT["MIDI"], "Melodic MIDI"
        return CAT["MIDI"], "Unknown"

    # Projects
    if ext in ABLETON_EXT:           return CAT["PROJECTS"], "Ableton Projects"
    if ext in FL_EXT:                return CAT["PROJECTS"], "FL Studio Projects"
    if ext in OTHER_DAW_EXT:         return CAT["PROJECTS"], "Other DAW Projects"

    # Presets
    if ext in SERUM_EXT or "serum" in name:
        if   any(k in name for k in KW["presets"]["bass"]):  return CAT["SERUM"], "Bass Presets"
        elif any(k in name for k in KW["presets"]["lead"]):  return CAT["SERUM"], "Lead Presets"
        elif any(k in name for k in KW["presets"]["pad"]):   return CAT["SERUM"], "Pad Presets"
        elif any(k in name for k in KW["presets"]["pluck"]): return CAT["SERUM"], "Pluck Presets"
        elif any(k in name for k in KW["presets"]["fx"]):    return CAT["SERUM"], "FX Presets"
        else:                                                return CAT["SERUM"], "Unknown"
    if ext in MASSIVE_EXT or "massive" in name:  return CAT["PRESETS_OTHER"], "Massive Presets"
    if "sylenth" in path.as_posix().lower():     return CAT["PRESETS_OTHER"], "Sylenth Presets"
    if ext in VITAL_EXT or "vital" in name:      return CAT["PRESETS_OTHER"], "Vital Presets"

    # Reference
    if ext in ART_EXT:                            return CAT["REFERENCE"], "Artwork"
    if ext in DOC_EXT:                            return CAT["REFERENCE"], "Documentation"
    if ext in DEMO_AUDIO_EXT and ("demo" in name or "preview" in name):
        return CAT["REFERENCE"], "Demo Tracks"

    # Audio
    if ext in AUDIO_EXT:
        # 808s FIRST
        if "808" in name:
            return CAT["DRUMS"], "808s"

        # Drums
        if any(k in name for k in KW["drums"]["kicks"]):   return CAT["DRUMS"], "Kicks"
        if any(k in name for k in KW["drums"]["snares"]):  return CAT["DRUMS"], "Snares"
        if any(k in name for k in KW["drums"]["claps"]):   return CAT["DRUMS"], "Claps"
        if any(k in name for k in KW["drums"]["hihats"]):  return CAT["DRUMS"], "Hi-Hats"
        if any(k in name for k in KW["drums"]["cymbals"]): return CAT["DRUMS"], "Cymbals"
        if any(k in name for k in KW["drums"]["perc"]):    return CAT["DRUMS"], "Percussion"
        if any(k in name for k in KW["drums"]["toms"]):    return CAT["DRUMS"], "Toms"
        if any(k in name for k in KW["drums"]["fxdrums"]): return CAT["DRUMS"], "FX Drums"

        # Loops
        if "loop" in name or "loops" in name:
            if any(k in name for k in KW["loops"]["drum"]): return CAT["LOOPS"], "Drum Loops"
            if any(k in name for k in KW["loops"]["bass"]): return CAT["LOOPS"], "Bass Loops"
            if any(k in name for k in KW["loops"]["fx"]):   return CAT["LOOPS"], "FX Loops"
            return CAT["LOOPS"], "Melodic Loops"

        # One shots
        if "one shot" in name or "oneshot" in name or "shot" in name:
            if   any(k in name for k in KW["oneshots"]["bass"]):      return CAT["ONE_SHOTS"], "Bass"
            elif any(k in name for k in KW["oneshots"]["piano"]):     return CAT["ONE_SHOTS"], "Piano"
            elif any(k in name for k in KW["oneshots"]["guitar"]):    return CAT["ONE_SHOTS"], "Guitar"
            elif any(k in name for k in KW["oneshots"]["synth"]):     return CAT["ONE_SHOTS"], "Synth"
            elif any(k in name for k in KW["oneshots"]["strings"]):   return CAT["ONE_SHOTS"], "Strings"
            elif any(k in name for k in KW["oneshots"]["brass"]):     return CAT["ONE_SHOTS"], "Brass"
            elif any(k in name for k in KW["oneshots"]["woodwinds"]): return CAT["ONE_SHOTS"], "Woodwinds"
            elif any(k in name for k in KW["oneshots"]["vocal"]):     return CAT["ONE_SHOTS"], "Vocal One Shots"
            elif any(k in name for k in KW["oneshots"]["fx"]):        return CAT["ONE_SHOTS"], "FX One Shots"
            else:                                                     return CAT["ONE_SHOTS"], "Unknown"

        # FX (generic)
        if any(k in name for k in KW["fx"]["impacts"]):     return CAT["FX"], "Impacts"
        if any(k in name for k in KW["fx"]["risers"]):      return CAT["FX"], "Risers"
        if any(k in name for k in KW["fx"]["downlifters"]): return CAT["FX"], "Downlifters"
        if any(k in name for k in KW["fx"]["uplifters"]):   return CAT["FX"], "Uplifters"
        if any(k in name for k in KW["fx"]["sweeps"]):      return CAT["FX"], "Sweeps"
        if any(k in name for k in KW["fx"]["atmos"]):       return CAT["FX"], "Atmospheres"
        if any(k in name for k in KW["fx"]["textures"]):    return CAT["FX"], "Textures"
        return CAT["FX"], "Unknown"

    return CAT["REFERENCE"], "Unknown"

def unique_rename(dst: Path) -> Path:
    if not dst.exists():
        return dst
    base, ext = dst.stem, dst.suffix
    i = 2
    while (dst.parent / f"{base} ({i}){ext}").exists():
        i += 1
    return dst.parent / f"{base} ({i}){ext}"

def move_file(src: Path, dst: Path, *, on_dup: str, dry_run: bool) -> Tuple[bool, str, Path]:
    try:
        dst.parent.mkdir(parents=True, exist_ok=True)
        final_dst = dst
        if dst.exists():
            if on_dup == "skip":
                return False, "exists (skipped)", dst
            elif on_dup == "overwrite":
                if not dry_run:
                    try:
                        dst.unlink()
                    except Exception:
                        pass
            elif on_dup == "rename":
                final_dst = unique_rename(dst)
        if dry_run:
            return True, "DRY-RUN (not moved)", final_dst
        shutil.move(str(src), str(final_dst))
        return True, "moved", final_dst
    except Exception as e:
        return False, f"error: {e}", dst

def prune_empty_dirs(root: Path, *, exclude: Path, dry_run: bool) -> Tuple[int, int]:
    removed = failed = 0
    for dirpath, dirnames, filenames in os.walk(root, topdown=False):
        d = Path(dirpath)
        # don't touch the output tree
        try:
            if exclude in d.parents or d == exclude:
                continue
        except Exception:
            pass
        try:
            if d.exists() and not any(d.iterdir()):
                if dry_run:
                    log(f"EMPTY DIR (preview) {ARROW} {d}")
                    removed += 1
                else:
                    d.rmdir()
                    log(f"EMPTY DIR removed {ARROW} {d}")
                    removed += 1
        except Exception as e:
            failed += 1
            log(f"EMPTY DIR prune failed {ARROW} {d} ({e})")
    return removed, failed

def main() -> int:
    parser = argparse.ArgumentParser(description="Move files into locked structure with Unknown buckets.")
    parser.add_argument("--root", default=DEFAULT_ROOT, help=f"Root to scan. Default: {DEFAULT_ROOT}")
    parser.add_argument("--out", default=DEFAULT_OUT, help="Destination root. Default: <ROOT>/Sorted_Cymatics")
    parser.add_argument("--dry-run", action="store_true", help="Preview actions without moving files.")
    parser.add_argument("--on-duplicate", choices=["skip", "overwrite", "rename"], default="skip",
                        help="What to do if destination exists (default: skip).")
    args = parser.parse_args()

    root = Path(args.root).expanduser()
    out_root = Path(args.out).expanduser() if args.out else (root / "Sorted_Cymatics")

    # Log header
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write("\n" + "="*80 + "\n")
        f.write(time.strftime("RUN START: %Y-%m-%d %H:%M:%S") + "\n")
        f.write(f"ROOT: {root}\nOUT: {out_root}\nDRY_RUN: {args.dry_run}\nON_DUPLICATE: {args.on_duplicate}\n")
        f.write("="*80 + "\n")

    log("Starting structure_sort_move.py (MOVE mode)")
    log(f"Root: {root}")
    log(f"Out : {out_root}")
    log(f"Duplicate policy: {args.on_duplicate}")

    if not root.exists():
        log("ERROR: Root does not exist.")
        return 2

    ensure_structure(out_root)

    files_scanned = files_moved = files_skipped = files_failed = 0

    for p in root.rglob("*"):
        if not p.is_file():
            continue
        # skip anything inside output tree
        try:
            if out_root in p.parents:
                continue
        except Exception:
            pass

        files_scanned += 1
        cat, sub = classify(p)
        dest = out_root / cat / sub / p.name

        moved, msg, final_dst = move_file(p, dest, on_dup=args.on_duplicate, dry_run=args.dry_run)
        if moved:
            files_moved += 1
            log(f"MOVE {ARROW} {p}  ==>  {final_dst}  ({msg})")
        else:
            if msg.startswith("exists"):
                files_skipped += 1
                log(f"SKIP (exists) {ARROW} {final_dst}")
            else:
                files_failed += 1
                log(f"FAIL {ARROW} {p}  ({msg})")

    # prune empty dirs in source (excluding the output tree)
    pruned, prune_failed = prune_empty_dirs(root, exclude=out_root, dry_run=args.dry_run)

    log("-" * 60)
    log(f"Scanned files   : {files_scanned}")
    log(f"Moved files     : {files_moved}")
    log(f"Skipped (exists): {files_skipped}")
    log(f"Failed moves    : {files_failed}")
    log(f"Empty dirs pruned: {pruned} (failed: {prune_failed})")
    log("Run end.")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        log("Interrupted by user.")
        raise SystemExit(130)
