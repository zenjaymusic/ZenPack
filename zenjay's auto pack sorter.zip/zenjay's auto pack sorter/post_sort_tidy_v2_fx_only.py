#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# FX Unknown tidy (v2): move Foley to FX/Atmospheres, melodic/BPM stuff to LOOPS/Melodic Loops

import argparse, shutil, time
from pathlib import Path

ROOT = Path(r"Z:\Audio Master\!PACKS\01 - LIBRARIES\01 - CYMATICS\Sorted_Cymatics")

FX_UNKNOWN = ROOT / r"05 - FX" / "Unknown"
FX_ATMOS   = ROOT / r"05 - FX" / "Atmospheres"
LOOPS_MELODIC = ROOT / r"02 - LOOPS" / "Melodic Loops"

LOG = ROOT / "post_sort_tidy_v2_fx_only_log.txt"

AUDIO_EXTS = {".wav", ".aiff", ".aif", ".flac", ".mp3", ".ogg", ".wma"}

# Heuristics (expanded)
FOLEY_KEYS   = {"walk","walking","footstep","forest","leaf","leaves","sand","park","life","foley","field"}
MELODIC_KEYS = {"melodic","melody","chord","guitar","piano","keys","pluck","arp","bordeaux","champagne","loop",
                "pad","bell","brass","string","strings","choir","vox","vocal","lead","synth","organ","harp","flute"}
DRUM_HINTS   = {"kick","snare","clap","hat","hihat","hi-hat","perc","tom","808"}

def log(msg: str):
    ts = time.strftime("[%Y-%m-%d %H:%M:%S]")
    line = f"{ts} {msg}"
    print(line)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")

def should_go_foley(name: str, ext: str) -> bool:
    return ext in AUDIO_EXTS and any(k in name for k in FOLEY_KEYS)

def should_go_melodic_loop(name: str, ext: str) -> bool:
    if ext not in AUDIO_EXTS: return False
    # block obvious drums
    if any(d in name for d in DRUM_HINTS): return False
    # melodic signals
    return ("bpm" in name) or ("loop" in name) or any(k in name for k in MELODIC_KEYS)

def move(src: Path, dst_dir: Path, commit: bool):
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / src.name
    if not commit:
        log(f"DRY-RUN: would move  {src}  -->  {dst}")
        return True
    try:
        if dst.exists():
            base, ext = dst.stem, dst.suffix
            i = 2
            while (dst_dir / f"{base} ({i}){ext}").exists(): i += 1
            dst = dst_dir / f"{base} ({i}){ext}"
        shutil.move(str(src), str(dst))
        log(f"MOVED: {src}  -->  {dst}")
        return True
    except Exception as e:
        log(f"ERROR moving {src}: {e}")
        return False

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--commit", action="store_true", help="Apply moves (default: dry-run)")
    args = ap.parse_args()

    for p in [FX_ATMOS, LOOPS_MELODIC]: p.mkdir(parents=True, exist_ok=True)
    log(f"Root: {ROOT} | Mode: {'COMMIT' if args.commit else 'DRY-RUN'}")

    if not FX_UNKNOWN.exists():
        log("No FX\\Unknown found. Nothing to do.")
        return

    foley_moved = melodic_moved = skipped = 0
    for p in sorted(FX_UNKNOWN.iterdir()):
        if not p.is_file(): continue
        name, ext = p.name.lower(), p.suffix.lower()

        if should_go_foley(name, ext):
            if move(p, FX_ATMOS, args.commit): foley_moved += 1
        elif should_go_melodic_loop(name, ext):
            if move(p, LOOPS_MELODIC, args.commit): melodic_moved += 1
        else:
            skipped += 1

    log(f"Summary: moved Foley={foley_moved}, moved Melodic/BPM={melodic_moved}, skipped={skipped}")

if __name__ == "__main__":
    main()
