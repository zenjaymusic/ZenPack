import os
import shutil

# Paths
root_dir = r"Z:\Audio Master\!PACKS\01 - LIBRARIES\01 - CYMATICS\Sorted_Cymatics\01 - DRUMS"
kicks_dir = os.path.join(root_dir, "KICKS")
target_dir = os.path.join(root_dir, "808s")

# Create target dir if missing
os.makedirs(target_dir, exist_ok=True)

moved_count = 0

for root, _, files in os.walk(kicks_dir):
    for file in files:
        if "808" in file.lower():
            src_path = os.path.join(root, file)
            dest_path = os.path.join(target_dir, file)

            try:
                shutil.move(src_path, dest_path)
                moved_count += 1
                print(f"MOVED: {src_path} -> {dest_path}")
            except Exception as e:
                print(f"ERROR moving {src_path}: {e}")

print(f"\n✅ Done. Moved {moved_count} file(s) to '808s' folder.")
